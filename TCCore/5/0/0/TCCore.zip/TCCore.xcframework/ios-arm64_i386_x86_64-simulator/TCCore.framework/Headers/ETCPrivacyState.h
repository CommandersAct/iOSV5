#ifndef __ETCPRIVACYSTATE_H__
#define __ETCPRIVACYSTATE_H__

typedef enum ETCPrivacyState
{
    TCPSWaitingForConsent,
    TCPSEnabled,
    TCPSDisabled
} ETCPrivacyState;

#endif //__ETCPRIVACYSTATE_H__
