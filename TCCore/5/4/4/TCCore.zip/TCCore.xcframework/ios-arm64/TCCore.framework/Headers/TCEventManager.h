//
//  TCEventManager.h
//  TCCore
//
//  Created by Abdelhakim SAID on 18/09/2025.
//  Copyright © 2025 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TCMacros.h"
#import "TCSingleton.h"
#import "ITCEventListenerDelegate.h"
#import "ITCEventSenderDelegate.h"
#import "ETCConsentState.h"
#import "ETCConsentBehaviour.h"
#import "TCEventListener.h"
#import "TCEventSender.h"
#import "TCCoreConstants.h"

@class TCEventListener;
@class TCEventSender;

@interface TCEventManager : TCSingleton <ITCEventListenerDelegate, ITCEventSenderDelegate>
SINGLETON_CLASS_H(TCEventManager)

@property (atomic, assign) ETCConsentBehaviour defaultBehaviour;
@property (nonatomic, retain) TCEventSender *senderDelegate;
@property (nonatomic, retain) TCEventListener *listenerDelegate;

- (void) callOnStoppingTheServerSide: (BOOL) shouldWaitForConsent;
- (void) callOnEnablingTheServerSide;

@end
