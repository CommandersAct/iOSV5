**SDK Licence Agreement FOR**  **COMMANDERS&#39; CLIENTS**

PLEASE READ CAREFULLY THE TERMS OF THIS SDK LICENSE AGREEMENT (&quot;AGREEMENT&quot;) BEFORE INSTALLING OUR SDK.

**IMPORTANT**

**THIS SKD CAN ONLY BE INSTALLED AND USED BY COMMANDERS ACT&#39; CLIENTS IN CONNECTION WITH OUR PRODUCTS.**

**IF YOU ARE NOT A COMMANDERS&#39; ACT CLIENTS AND DECIDE TO INSTALL AND USE OUR SDK, WE SHALL NOT LIABLE FOR ANY CONSEQUENCE RESULTING FROM THE INSTALLATION AND/OR THE USE OF**  **OUR SDK and you are likely to be subject to prosecution for unauthorized use of our SDK**.

BY INSTALLING, ACCESSING AND/OR USING OUR SDK, YOU EXPRESSLY ACKNOWLEDGE AND AGREE THAT YOU, OR THE COMPANY YOU REPRESENT, (&quot;YOU&quot; OR &quot;LICENSEE&quot;) ARE ENTERING INTO A LEGAL AGREEMENT WITH COMMANDERS ACT, AND HAVE UNDERSTOOD AND AGREE TO COMPLY WITH, AND BE LEGALLY BOUND BY, THE TERMS AND CONDITIONS OF THIS AGREEMENT.

- - - -

1. **Definitions.**

- -- **Documentation** means the user&#39;s guides and technical manuals delivered by COMMANDERS ACT to Licensee.
- -- **Intellectual Property Rights** means all intangible legal rights, titles and interests evidenced by or embodied in SDK.
- -- **License** means the right to use SDK pursuant to this Agreement.
- -- **Products** means any product, service, platform provided by COMMANDERS ACT.
- -- **SDK** means SDK Development Kit created by COMMANDERS ACT in connection with its Products including any updates and upgrade thereto (to the extent delivered) **.**

1. **Term and Termination.**

This Agreement shall continue as long as You have a subscription to a Product compatible with the SDK (the &quot;Term&quot;).

In the event of termination of Your subscription to a Product compatible with the SDK, this Agreement will be automatically terminated provided that You have removed the SDK from Your system and destroyed all copies of the SDK and Documentation.

Unauthorized copying of the SDK or otherwise failing to comply with this Agreement will result in automatic immediate termination of this Agreement and will make available to COMMANDERS ACT legal remedies.

COMMANDERS ACT reserves the right to terminate this Agreement and the License at any time and without notice.

Upon termination of this Agreement, the License will terminate and You: (i) will cease any and all rights to use the SDK, and (ii) will remove the SDK from all hard drives, networks and other storage media and destroy all copies of the SDK in your possession or under your control.

The provisions above shall survive the termination, expiration or other ending of this Agreement.

1. **License scope**

Subject to the terms and conditions of this Agreement, COMMANDERS ACT grants You, during the Term, a personal, non-exclusive, non-sublicensable, non-transferable, revocable license to: (i) use the SDK solely in connection with COMMANDERS ACT&#39;s PRODUCTS.

COMMANDERS ACT shall make available Documentation to be used solely in connection with Licensee&#39;s use of the SDK during the Term of this Agreement.

Licensee may print or copy the Documentation as needed for its own purposes provided that all copyright notices are included therein.

Documentation shall be considered as confidential information of COMMANDERS ACT.

Licensee shall have no other rights, express or implied, in the SDK, other than the rights explicitly granted in this Agreement.

Without limiting the generality of the foregoing, Licensee agrees and undertakes not to: (i) allow any third party to use the SDK in any manner, including but not limited to, sell, lease, sublicense or distribute the SDK, or any part thereof; (ii) modify, revise, or alter the SDK or reverse engineer, decompile, disassemble or otherwise reduce to human-perceivable form the SDK&#39;s source code; (iii) copy or allow copies of the SDK to be made; (iv) remove, alter or obscure any proprietary notice or identification, contained in or displayed on or via the SDK; (v) use the SDK to violate any applicable laws, rules or regulations, or for any unlawful, harmful, irresponsible, or inappropriate purpose, or in any manner that breaches this Agreement, and/or (vi) represent that it possesses any proprietary interest in the SDK.

1. **Open Source Licenses**

The SDK may include certain open source code and materials (as shall be listed in the documentation of the SDK) (&quot;Open Source Code&quot;) that are subject to their respective open source licenses (&quot;Open Source Licenses&quot;).

Such Open Source Licenses contain a list of conditions with respect to warranty, copyright policy and other provisions.

By executing this Agreement, Licensee undertakes to strictly comply with the terms and condition of the Open Source Licenses, as may be amended from time to time.

In order to comply with the Open Source Licenses, Licensee shall read the respective licenses or notices, such list of Open Source Licenses may be amended from time to time by COMMANDERS ACT, at its sole discretion.

In the event of any inconsistencies or conflicting provisions between the provisions of the Open Source Licenses and the provisions of this Agreement, the provisions of the Open Source Licenses shall prevail.

Without derogating from the generality of the foregoing, it is clarified that any Open Source Code is provided on an &quot;AS IS&quot; basis, without indemnity or warranty of any kind, whether express or implied.

For clarity, the representations and warranties set forth in this Agreement shall not apply to any Open Source Code.

1. **Ownership**

COMMANDERS ACT DOES NOT SELL OR TRANSFER ANY TITLE IN THE SDK, OR ANY PART THEREOF, TO LICENSEE. T

Documentation, SDK (excluding any Open Source Code) shall remain COMMANDERS ACT&#39; sole and exclusive property.

All Intellectual Property Rights evidenced by or embodied in and/or related to the SDK, or part thereof, are and shall be owned solely and exclusively by COMMANDERS ACT.

Nothing in this Agreement shall constitute a waiver of COMMANDERS ACT&#39; Intellectual Property Rights or be in any way construed or interpreted as such.

It is further agreed that Licensee acknowledges that any and all rights, including Intellectual Property Rights in any evolution shall belong exclusively to COMMANDERS ACT.

1. **Warranty**

COMMANDERS ACT warrants that it has the right to grant the license under this Agreement. COMMANDERS ACT&#39; sole liability for any breach of this warranty or any other warranty under this Agreement shall be, at COMMANDERS ACT&#39; sole discretion: (i) to replace or repair the SDK or the applicable portion thereof; or (ii) to terminate this Agreement.

The warranties set forth above are contingent upon Licensee&#39;s proper use of the SDK, and shall not apply to damage caused by abuse, misuse, alteration, neglect or unauthorized repair or installation, or by the use or attempted use of SDK other than that supplied and supported by COMMANDERS ACT.

COMMANDERS ACT will use reasonable commercial efforts to repair or replace the SDK or the applicable portion thereof, as soon as possible.

1. **Indemnification**

You agree that COMMANDERS ACT shall have no liability whatsoever for any use made of the SDK by You or any third party. You hereby agree to defend, indemnify and hold harmless COMMANDERS ACT from any and all claims, damages, liabilities, costs, and expenses (including attorney&#39;s fees) arising from claims related to Your use of the SDK as well as from Your failure to comply with this Agreement.

1. **Limitation of Liability**

UNDER NO CIRCUMSTANCES SHALL COMMANDERS ACT BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE OR CONSEQUENTIAL DAMAGES, OR FOR ANY LOSS OF DATA, REVENUE, BUSINESS OR REPUTATION, THAT ARISES UNDER OR IN CONNECTION WITH THIS AGREEMENT, OR THAT RESULTS FROM THE USE OF, OR THE INABILITY TO USE, THE SDK.

COMMANDERS ACT&#39;S TOTAL AGGREGATE LIABILITY FOR ANY AND ALL DIRECT DAMAGES AND LOSSES THAT ARISE UNDER OR IN CONNECTION WITH THIS AGREEMENT SHALL NOT IN ANY CIRCUMSTANCE EXCEED THE AMOUNT OF €1000.

THE FOREGOING LIMITATIONS AND EXCLUSIONS IN THIS SECTION ‎SHALL APPLY: (I) EVEN IF COMMANDERS ACT HAS BEEN ADVISED OF THE POSSIBILITY OF ANY DAMAGES OR LOSSES; (II) EVEN IF ANY REMEDY SET FORTH HEREIN FAILS OF ITS ESSENTIAL PURPOSE; AND (III) REGARDLESS OF THE BASIS OR THEORY OF LIABILITY.

1. **Miscellaneous**

This Agreement represents the complete agreement concerning the SDK between You and COMMANDERS ACT and supersedes all prior agreements and representations between You and COMMANDERS ACT.

If any provision of this Agreement is held to be unenforceable for any reason, such provision shall be reformed only to the extent necessary to make it enforceable.

Any waiver of any provision of this Agreement will be effective only if in writing and signed by COMMANDERS ACT.

This Agreement is personal to You and may not be assigned or transferred for any reason whatsoever without the consent of COMMANDERS ACT and any action or conduct in violation of the foregoing shall be void and without effect.

COMMANDERS ACT expressly reserves the right to assign this Agreement and to delegate any of its obligations hereunder.

1. **Law and jurisdiction**

This Agreement is governed by and construed under the laws of the State of France.

You expressly agree that the exclusive jurisdiction for any claim or action arising out of or relating to this Agreement shall be the courts located in Paris, France.