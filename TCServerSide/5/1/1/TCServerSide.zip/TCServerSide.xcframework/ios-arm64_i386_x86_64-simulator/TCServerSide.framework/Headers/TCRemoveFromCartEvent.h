//
//  TCRemoveFromCartEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCRemoveFromCartEvent_h
#define events_TCRemoveFromCartEvent_h

#import "TCECommerceEvent.h"

@interface TCRemoveFromCartEvent : TCECommerceEvent

@property (nonatomic, retain) NSDecimalNumber *value;

- (instancetype) initWithItems: (NSArray *) TCItems;

@end

#endif
