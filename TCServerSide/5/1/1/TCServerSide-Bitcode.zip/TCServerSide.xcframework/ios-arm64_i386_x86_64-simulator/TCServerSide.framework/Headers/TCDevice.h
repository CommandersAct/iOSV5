//
//  TCDevice.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef schemes_TCDevice_h
#define schemes_TCDevice_h

#import <Foundation/Foundation.h>
#import <TCCore/TCSingleton.h>
#import <TCCore/TCMacros.h>

@interface TCDevice : TCSingleton

SINGLETON_CLASS_H(TCDevice)
- (NSDictionary *) getJsonObject;
- (void) setAdvertisingIds;

@end

#endif
