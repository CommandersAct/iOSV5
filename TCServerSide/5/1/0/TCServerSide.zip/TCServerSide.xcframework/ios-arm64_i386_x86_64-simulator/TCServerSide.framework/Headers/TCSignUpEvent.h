//
//  TCSignUpEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCSignUpEvent_h
#define events_TCSignUpEvent_h

#import "TCEvent.h"

@interface TCSignUpEvent : TCEvent

@property (nonatomic, retain) NSString *method;

@end

#endif
