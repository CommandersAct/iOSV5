//
//  TCBeginCheckoutEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCBeginCheckoutEvent_h
#define events_TCBeginCheckoutEvent_h

#import "TCECommerceEvent.h"

@interface TCBeginCheckoutEvent : TCECommerceEvent

@property (nonatomic, retain) NSDecimalNumber * _Nullable revenue;
@property (nonatomic, retain) NSDecimalNumber * _Nullable value;
@property (nonatomic, retain) NSString *_Nullable coupon;

- (instancetype) initWithRevenue: (NSDecimalNumber *) revenue withValue: (NSDecimalNumber *) value withCurrency: (NSString *) currency withItems: (NSArray *) TCItems;

@end

#endif
