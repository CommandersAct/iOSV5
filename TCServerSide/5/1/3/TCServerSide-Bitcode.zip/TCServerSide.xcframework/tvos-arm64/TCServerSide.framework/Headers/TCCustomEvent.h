//
//  TCCustomEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 18/03/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCCustomEvent_h
#define events_TCCustomEvent_h

#import "TCEvent.h"

@interface TCCustomEvent : TCEvent

- (instancetype) initWithName: (NSString *) eventName;

@end

#endif
