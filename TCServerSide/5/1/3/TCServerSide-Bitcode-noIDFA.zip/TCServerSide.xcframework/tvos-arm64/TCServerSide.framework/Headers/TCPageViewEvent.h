//
//  TCPageViewEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCPageViewEvent_h
#define events_TCPageViewEvent_h

#import "TCEvent.h"

@interface TCPageViewEvent : TCEvent

- (instancetype) initWithType: (NSString *) type;

@end

#endif
