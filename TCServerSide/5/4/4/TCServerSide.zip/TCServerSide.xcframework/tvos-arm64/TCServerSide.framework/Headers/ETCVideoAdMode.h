//
//  ETCVideoAdMode.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef ETCVideoAdMode_h
#define ETCVideoAdMode_h

typedef enum ETCVideoAdMode
{
   video_ad_start,
   video_ad_playing,
   video_ad_stop,
   video_ad_complete,
   video_ad_skip,
   video_ad_break_start,
   video_ad_break_complete,
   video_ad_click
} ETCVideoAdMode;

extern NSString * const ETCVideoAdMode_toString[];

#endif /* ETCVideoAdMode_h */
