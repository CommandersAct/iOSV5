//
//  TCVideoContentEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 31/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCVideoContentEvent_h
#define TCVideoContentEvent_h
#if __has_include(<TCServerSide_noIDFA/ServerSide.h>)
#import <TCServerSide_noIDFA/TCVideoEvent.h>
#import <TCServerSide_noIDFA/ETCVideoContentMode.h>
#else
#import <TCServerSide/TCVideoEvent.h>
#import <TCServerSide/ETCVideoContentMode.h>
#endif


@interface TCVideoContentEvent : TCVideoEvent

- (instancetype) initWithMode: (ETCVideoContentMode) mode andSessionId: (NSString *) sessionID;

@property (nonatomic, retain) NSString* contentPodID;
@property (nonatomic, retain) NSString* videoDescription;
@property (nonatomic, retain) NSString* season;
@property (nonatomic, retain) NSString* episode;
@property (nonatomic, retain) NSString* videoCategory;
@property (nonatomic, retain) NSString* program;
@property (nonatomic, retain) NSString* channel;
@property (nonatomic, retain) NSString* airDate; //ISO 8601 Date String
@property (nonatomic, retain) NSString* contentAssetID;
@property (nonatomic, retain) NSMutableArray* keywords;
@property BOOL fullEpisode;
@property BOOL livestream;
@property (nonatomic, retain) NSDecimalNumber* bitrate;
@property (nonatomic, retain) NSDecimalNumber* framerate;

@end

#endif /* TCVideoContentEvent_h */
