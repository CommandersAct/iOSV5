//
//  ETCVideoPlaybackMode.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef ETCVideoPlaybackMode_h
#define ETCVideoPlaybackMode_h

typedef enum ETCVideoPlaybackMode
{
    video_start,
    video_pause,
    video_error,
    video_buffer_start,
    video_buffer_complete,
    video_seek_start,
    video_seek_complete,
    video_resume,
    video_complete
} ETCVideoPlaybackMode;

extern NSString * const ETCVideoPlaybackMode_toString[];

#endif /* ETCVideoPlaybackMode_h */
