//
//  ETCAdLoadType.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef ETCAdLoadType_h
#define ETCAdLoadType_h

typedef enum ETCAdLoadType
{
    dynamic,
    linear
} ETCAdLoadType;

extern NSString * const ETCAdLoadType_toString[];

#endif /* ETCAdLoadType_h */
