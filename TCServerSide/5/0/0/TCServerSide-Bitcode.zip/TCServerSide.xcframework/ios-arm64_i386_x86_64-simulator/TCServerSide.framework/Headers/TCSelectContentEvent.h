//
//  TCSelectContentEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCSelectContentEvent_h
#define events_TCSelectContentEvent_h

#import "TCEvent.h"

@interface TCSelectContentEvent : TCEvent

@property (nonatomic, retain) NSString *contentType;
@property (nonatomic, retain) NSString *itemID;

@end

#endif
