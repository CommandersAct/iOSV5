//
//  TCEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCEvent_h
#define events_TCEvent_h

#import <Foundation/Foundation.h>
#import "TCEventPropertiesNames.h"
#import <TCCore/TCUtils.h>
@class TCDynamicStore;

@interface TCEvent : NSObject

- (BOOL) verifyEvent;
- (NSMutableDictionary *) getJsonObject;
- (void) addAdditionalParameter: (NSString *) key withValue: (NSString *) value ;
- (void) addAdditionalParameter: (NSString *) key forJsonDict: (NSDictionary *) json;
- (void) addAdditionalParameter: (TCDynamicStore *) store;
- (TCDynamicStore *) getAdditionalParameters;
- (NSArray *) getItemListAsJson: (NSArray *) items;

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) TCDynamicStore *additionalParameters;
@property (nonatomic, retain) NSString *pageType;
@property (nonatomic, retain) NSString *pageName;

@end

#endif
