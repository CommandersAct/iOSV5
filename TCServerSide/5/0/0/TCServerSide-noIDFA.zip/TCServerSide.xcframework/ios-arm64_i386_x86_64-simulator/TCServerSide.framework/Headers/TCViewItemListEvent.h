//
//  TCViewItemListEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCViewItemListEvent_h
#define events_TCViewItemListEvent_h

#import "TCEvent.h"

@interface TCViewItemListEvent : TCEvent

@property (nonatomic, retain) NSString *itemListName;
@property (nonatomic, retain) NSMutableArray *items;

- (instancetype) initWithItems: (NSArray *) TCItems;

@end

#endif
