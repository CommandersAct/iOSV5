//
//  TCViewItem.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 20/01/2022.
//  Copyright © 2022 TagCommander. All rights reserved.
//

#ifndef events_TCViewItem_h
#define events_TCViewItem_h

#import "TCECommerceEvent.h"

@interface TCViewItem : TCECommerceEvent

@property (nonatomic, retain) NSDecimalNumber *revenue;

- (instancetype) initWithItems: (NSArray *) TCItems;

@end

#endif
