//
//  ETCAdType.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef ETCAdType_h
#define ETCAdType_h

typedef enum ETCAdType
{
    pre_roll,
    mid_roll,
    post_roll
} ETCAdType;

extern NSString * const ETCAdType_toString[];

#endif /* ETCAdType_h */
