//
//  TCVideoAdEvent.h
//  TCServerSide
//
//  Created by Abdelhakim SAID on 30/03/2023.
//  Copyright © 2023 TagCommander. All rights reserved.
//

#ifndef TCVideoAdEvent_h
#define TCVideoAdEvent_h

#if __has_include(<TCServerSide_noIDFA/TCVideoEvent.h>)
#import <TCServerSide_noIDFA/TCVideoEvent.h>
#import <TCServerSide_noIDFA/ETCAdType.h>
#import <TCServerSide_noIDFA/ETCAdLoadType.h>
#import <TCServerSide_noIDFA/ETCVideoAdMode.h>
#else
#import <TCServerSide/TCVideoEvent.h>
#import <TCServerSide/ETCAdType.h>
#import <TCServerSide/ETCAdLoadType.h>
#import <TCServerSide/ETCVideoAdMode.h>
#endif

@interface TCVideoAdEvent : TCVideoEvent

- (instancetype) initWithMode: (ETCVideoAdMode) mode andSessionId: (NSString *) sessionID;

@property (nonatomic, retain) NSString* adAssetID;
@property (nonatomic, retain) NSString* adPodID;
@property (nonatomic, retain) NSDecimalNumber* podPosition;
@property (nonatomic, assign) ETCAdType adType;
@property (nonatomic, retain) NSDecimalNumber* podLength;
@property (nonatomic, assign) ETCAdLoadType loadType;
@property (nonatomic, retain) NSDecimalNumber* adQuartile;

@end

#endif /* TCVideoAdEvent_h */
